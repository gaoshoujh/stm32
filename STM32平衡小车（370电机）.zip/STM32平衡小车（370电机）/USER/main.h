#ifndef __MAIN_H_
#define __MAIN_H_

int Senor_Using();

#endif
